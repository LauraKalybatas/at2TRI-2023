const leia = require('prompt-sync')();

const codigo = ["COD01","COD02", "COD03", "COD04","COD05", "COD06", "COD07","COD08", "COD09", "COD10"];
const servico = ["Inclusão Artistica para Surdos","Inclusão Artistica para Cegos", "Exposição de Pessoas Com Deficiencia", "Apoio a Artistas PCDs","Apoio a Artistas Pretos", "Apoio a Artistas em necessidade", "Apoio a Artistas Indígenas","Apoio a Artistas Neurodivergentes", "Arte e Psicologia: reunioes para spt", "Oficinas de arte grauitas"];
const valorUnitarioDoacao = [10, 20, 15, 5, 25, 30, 25, 10, 30, 5];
const movimento = ["0", "0","0"];

let index = 0;
let total = 0;

function finalizar(){
    console.log("Carrinho final:");
    for(i = 0; i < movimento.length; i++){
        index = codigo.indexOf(movimento[i]);
        console.log(codigo[index] + "\t" + servico[index] + "\t" + valorUnitarioDoacao[index]);
        total += valorUnitarioDoacao[index];
    }
    console.log(`Total: ${total}`);
    let quer = leia("Gostaria de finalizar a doação(F) ou cancelar(C)? ");
    if(quer == "F"){
        let quer = leia("Doação concluída! Gostaria de continuar?(S/N) ");
        if(quer == "S"){
            fazerDoacoes();
        } else {
            console.log("Muito Obrigada! Até breve!")
        }
    } else {
        console.log("Operação cancelada. Até breve!")
    }
}

function fazerDoacoes(){
    let i = 0;
    while(i < movimento.length){
        console.log(`Doação ${i + 1}`);
        for(j = 0; j < codigo.length; j++){
            console.log(codigo[j] + "\t" + servico[j] + "\t" + valorUnitarioDoacao[j]);
        }
        let doou = leia("Qual é o valor a ser doado? ");
        if(movimento.includes(doou)){
            console.log("Você já escolheu essa opção, tente novamente");
        } else {
            movimento[i] = doou;
            console.log(movimento)
            i++;

            if(i < movimento.length){
                let quer = leia("Gostaria de continuar?(S/N) ");
                if(quer == "N"){
                    finalizar();
                    break;
                }
            } else {
                finalizar();
                break;
            }
        }
    }
}

let quer = leia("Gostaria de fazer doações?(S/N) ");
if(quer == "S"){
    fazerDoacoes();
} else {
    console.log("Até breve!")
}
